var main = function (input) {
  var myOutputValue = 'hello world';
  return myOutputValue;
};
